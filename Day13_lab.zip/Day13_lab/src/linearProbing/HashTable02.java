package linearProbing;

public class HashTable02 implements HashTableIntf {

	class Bucket {
		int key;
	}

	Bucket[] ht;
	int size;

	public HashTable02(int size) {
		this.size = size;
		ht = new Bucket[size];
	}

	private int HashFunctionModN(int key) {
		return key % size;
	}

	@Override
	public boolean Add(int key) {
		int bucketId = HashFunctionModN(key);
		System.out.println("For key " + key + ", bucketId is " + bucketId);

		if (ht[bucketId] != null) {
			while (ht[bucketId] != null) {
				if (ht[bucketId].key == key) {
					System.out.println("Duplicate key " + key);
					return true;
				}
				++bucketId;
			}
			System.out.println("new bucketId " + bucketId);
		}

		ht[bucketId] = new Bucket();
		ht[bucketId].key = key; // ht[bucketId].Add(key);
		System.out.println("Added key " + key);
		return true;
	}

	@Override
	public boolean Search(int key) {
		int bucketId = HashFunctionModN(key);
		System.out.println("For key " + key + ", search bucketId " + bucketId);

		if (ht[bucketId] != null) {
			int i = bucketId;
			for (i = bucketId; i <= size; i++) {
				if (ht[bucketId].key == key) {
					System.out.println("Found key " + key);
					return true;
				} else {
					System.out.println(key + " not found in bucket " + bucketId);
				}
				++bucketId;
			}
		}
		return false;
	}

	@Override
	public boolean Delete(int key) {
		int bucketId = HashFunctionModN(key);
		System.out.println("For key " + key + ", search bucketId " + bucketId);

		if (ht[bucketId] != null) {
			int i = bucketId;
			for (i = bucketId; i <= size; i++) {
				if (ht[bucketId].key == key) {
					ht[bucketId] = null;
					System.out.println(ht[bucketId]);
					return true;
				} else {
					System.out.println(key + " not found in bucket " + bucketId);
				}
				++bucketId;
			}
		}
		return false;

	}
}
