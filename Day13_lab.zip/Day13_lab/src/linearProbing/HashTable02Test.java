package linearProbing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HashTable02Test {

	@Test
	void tes01Add() {
		System.out.println("-------------------");
		System.out.println("In test 01");
		HashTable02 ht = new HashTable02(10);
		assertTrue(ht.Add(2));
		assertTrue(ht.Add(12));
		assertTrue(ht.Add(12));
	}

	@Test
	void tes02Search() {
		System.out.println("-------------------");
		System.out.println("In test 02");
		HashTable02 ht = new HashTable02(10);
		assertTrue(ht.Add(2));
		assertTrue(ht.Add(7));
		assertTrue(ht.Add(12));
		assertTrue(ht.Search(12));
		assertFalse(ht.Search(10));
		assertTrue(ht.Search(2));
		assertTrue(ht.Search(7));
	}
	
	@Test
	void tes03Delete() {
		System.out.println("-------------------");
		System.out.println("In test 03");
		HashTable02 ht = new HashTable02(10);
		assertTrue(ht.Add(3));
		assertTrue(ht.Add(12));
		assertTrue(ht.Delete(12));
		assertFalse(ht.Delete(5));
	}
}
