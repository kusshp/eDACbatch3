package separateChaining;

public class HashTable03 implements HashTableIntf {

	int size = 10;
	private Node[] node = new Node[size];

	private int HashFunctionModN(int key) {
		return key % size;
	}

	@Override
	public void Add(int key, String value) {
		Node newNode = new Node(value);
		int bucketId = HashFunctionModN(key);
		System.out.println("For key " + key + ", bucketId is " + bucketId);

		if (node[bucketId] == null) {
			node[bucketId] = newNode;
			
		} else {
			Node curr = node[bucketId];
			while (curr != null) {
				curr = curr.next;
			}
			curr = newNode;
			System.out.println(value + " is added at " + curr);
		}
	}

	@Override
	public boolean Search(int key, String value) {
		int bucketId = HashFunctionModN(key);
		if (node[bucketId] == null) {
			return false;
		} else {
			if (node[bucketId].data.equals(value)) {
				return true;
			} else {
				Node curr = node[bucketId];
				while (curr != null) {
					if (curr.data.equals(value))
						return true;
					System.out.println(curr);
					curr = curr.next;
				}
			}
		}
		return false;
	}

	@Override
	public void Delete(int key) {
		// TODO Auto-generated method stub

	}

}