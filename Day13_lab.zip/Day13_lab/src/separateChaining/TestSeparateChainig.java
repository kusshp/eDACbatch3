package separateChaining;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestSeparateChainig {

	@Test
	void testAdd() {
		HashTable03 hs = new HashTable03();
		hs.Add(5, "raj");
		hs.Add(15, "pal");
		assertTrue(hs.Search(5, "raj"));
		assertTrue(hs.Search(15, "pal"));
	}
	
	@Test
	void testSearch() {
		HashTable03 hs = new HashTable03();
		hs.Add(5, "raj");
		hs.Add(6, "pal");
		hs.Add(15, "jim");
		assertTrue(hs.Search(5, "raj"));
		assertTrue(hs.Search(6, "pal"));
		assertTrue(hs.Search(15, "jim"));
		assertFalse(hs.Search(5, "jim"));
	}

}
