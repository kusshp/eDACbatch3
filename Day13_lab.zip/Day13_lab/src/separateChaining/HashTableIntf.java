package separateChaining;
public interface HashTableIntf {
	// Return false in case of collision.
	public void Add(int key, String value);

	public boolean Search(int key, String value);

	public void Delete(int key);
}
